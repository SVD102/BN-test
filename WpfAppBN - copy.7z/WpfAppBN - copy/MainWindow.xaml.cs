﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfAppBN
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private float delta = 0.5f;

		private void Canvas_MouseWheel(object sender, MouseWheelEventArgs e)
		{
            var st = (sender as Canvas).RenderTransform as ScaleTransform;

            if (e.Delta > 0)
            {
                st.ScaleX += delta;
                st.ScaleY += delta;
            }
            else
            {
                st.ScaleX -= delta;
                st.ScaleY -= delta;
            }

            (sender as Canvas).UpdateLayout();
        }
	}
}
