﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.Configuration.Attributes;

namespace WpfAppBN
{	public sealed class PointMap : ClassMap<Point>
    {
        public PointMap()
        {
            Map(m => m.X).Index(0).Name("X");
            Map(m => m.Y).Index(1).Name("Y");
        }
    }

    public sealed class RectMap : ClassMap<Rect>
    {
        public RectMap()
        {
            Map(m => m.X).Index(0).Name("X");
            Map(m => m.Y).Index(1).Name("Y");

            Map(m => m.Width).Index(2).Name("Width");
            Map(m => m.Height).Index(3).Name("Height");

            Map(m => m.Bottom).Ignore();
            Map(m => m.BottomLeft).Ignore();
            Map(m => m.BottomRight).Ignore();
            Map(m => m.IsEmpty).Ignore();
            Map(m => m.Left).Ignore();
            Map(m => m.Location).Ignore();
            Map(m => m.Right).Ignore();
            Map(m => m.Size).Ignore();
            Map(m => m.Top).Ignore();
            Map(m => m.TopLeft).Ignore();
            Map(m => m.TopRight).Ignore();
        }
    }

    public struct Segment : INotifyPropertyChanged
    {
        //public Point Point1 { get; set; }
        //public Point Point2 { get; set; }

        public double X1 { get; set; }
        public double Y1 { get; set; }

        public double X2 { get; set; }
        public double Y2 { get; set; }

        public bool IsContainsRectangle { get; set; }

        public void SetIsContainsRectangle(bool value)
		{
            IsContainsRectangle = value;
		}

        public event PropertyChangedEventHandler PropertyChanged;
    }

    public struct PolyLine
    {
        public LinkedList<Point> Points { get; set; }

        public ObservableCollection<Segment> Segments { get; set; }

        public void FillSegments()
        {
            if (Points.Count() == 0)
                return;

            var currentPoint = Points.First;

            while (currentPoint != null)
            {
                var segment = new Segment()
                {
                    X1 = currentPoint.Value.X,
                    Y1 = currentPoint.Value.Y,
                };
                
                var point1 = currentPoint.Value;
                
                currentPoint.Value = point1;

                currentPoint = currentPoint.Next;

                if (currentPoint.Next != null)
                {
                    segment.X2 = currentPoint.Value.X;
                    segment.Y2 = currentPoint.Value.Y;

                    var point2 = currentPoint.Value;
                
                    currentPoint.Value = point2;
                }
				else // отрезок из 1 точки
				{
                    segment.X2 = segment.X1;
                    segment.Y2 = segment.Y1;
                }

                Segments.Add(segment);

                if (currentPoint == null || currentPoint.Next == null)
                    break;
            }
        }
    }

    public class MainViewModel : INotifyPropertyChanged
    {
        public Visibility VisibilityProgressBar { get; set; } = Visibility.Hidden;
        public string StatusText { get; set; } = string.Empty;

        public ObservableCollection<PolyLine> PolyLines { get; set; } = new ObservableCollection<PolyLine>(); //PolyLineSegment
        public Rect Rectangle { get; set; } = new Rect();

        public RelayCommand LoadDataFromFile
        {
            get => new RelayCommand(obj =>
            {
                VisibilityProgressBar = Visibility.Visible;
                var text = string.Empty;

                try
                {
                    var config = new Configuration()
                    {
                        CultureInfo = CultureInfo.InvariantCulture,
                        HasHeaderRecord = true,
                        Delimiter = ",",
                    };
                    config.RegisterClassMap<PointMap>();

                    var pathBaseDirectory = AppDomain.CurrentDomain.BaseDirectory;
                    var pathToDirectoryPolyLines = Path.Combine(pathBaseDirectory, "PolyLines");

                    if (Directory.Exists(pathToDirectoryPolyLines))
                    {
                        var directoryPolyLines = new DirectoryInfo(pathToDirectoryPolyLines);
                        foreach (var filePolyLine in directoryPolyLines.GetFiles())
                        {
                            using (var reader = new StreamReader(filePolyLine.FullName))
                            using (var csv = new CsvReader(reader, config))
                            {
                                var points = csv.GetRecords<Point>();
                                var polyLine = new PolyLine() { Points = new LinkedList<Point>(points), Segments = new ObservableCollection<Segment>(), };
                                polyLine.Points.AddLast(new Point() { X = 110, Y = 120 });
                                polyLine.Points.AddLast(new Point() { X = 120, Y = 125 });
                                polyLine.FillSegments();
                                PolyLines.Add(polyLine);
                            }
                        }
                    }

                    config.UnregisterClassMap();
                    var pathToRectangleFile = Path.Combine(pathBaseDirectory, "rectangles.csv");
                    using (var reader = new StreamReader(pathToRectangleFile))
                    using (var csv = new CsvReader(reader, config))
                    {
                        var rectangles = csv.GetRecords<Rect>(); //1
                        Rectangle = rectangles.FirstOrDefault();
                    }

                    text = "Данные c файлов прочитаны.";
                }
                catch (Exception exc)
                {
                    text = exc.Message;
                }

                VisibilityProgressBar = Visibility.Hidden;
                StatusText = text;
            });
        }

        public RelayCommand FindSegmentsFromRectangle
        {
            get => new RelayCommand(obj =>
            {
                VisibilityProgressBar = Visibility.Visible;

                var text = string.Empty;

                try
                {
                    if (Rectangle == Rect.Empty)
                        return;

                    //(O(n^2)) :-(

                    for (int p = 0; p < PolyLines.Count(); p++)
                    {
                        for (int s = 0; s < PolyLines[p].Segments.Count(); s++)
                        {
                            var segment = PolyLines[p].Segments[s];

                            if (segment.X1 < Rectangle.X)
                            {
                                if (segment.X2 < Rectangle.X)
                                {
                                    continue;
                                }
                                else
                                {
                                    if (segment.Y1 < Rectangle.Y && segment.Y2 < Rectangle.Y)
                                        continue;
                                    else if ((segment.Y1 > Rectangle.Y + Rectangle.Height) && (segment.Y2 > Rectangle.Y + Rectangle.Height))
                                        continue;
                                    else
                                    {
                                        //можно проверить отрезок на полную вложенность в область и перешагнуть через 1 отрезок на следующий

                                        segment.IsContainsRectangle = true;
                                        PolyLines[p].Segments[s] = segment;
                                    }
                                }
                            }
                            else if (segment.X2 < Rectangle.X)
                            {
                                if (segment.Y1 < Rectangle.Y && segment.Y2 < Rectangle.Y)
                                    continue;
                                else if ((segment.Y1 > Rectangle.Y + Rectangle.Height) && (segment.Y2 > Rectangle.Y + Rectangle.Height))
                                    continue;
                                else
                                {
                                    segment.IsContainsRectangle = true;
                                    PolyLines[p].Segments[s] = segment;
                                }
                            }
                            else if (segment.X1 > Rectangle.X + Rectangle.Width)
                            {
                                if (segment.X2 > Rectangle.X + Rectangle.Width)
                                {
                                    continue;
                                }
                                else
                                {
                                    if (segment.Y1 < Rectangle.Y && segment.Y2 < Rectangle.Y)
                                        continue;
                                    else if ((segment.Y1 > Rectangle.Y + Rectangle.Height) && (segment.Y2 > Rectangle.Y + Rectangle.Height))
                                        continue;
                                    else
                                    {
                                        segment.IsContainsRectangle = true;
                                        PolyLines[p].Segments[s] = segment;
                                    }
                                }
                            }
                            else if (segment.X2 > Rectangle.X + Rectangle.Width)
                            {
                                if (segment.X1 > Rectangle.X + Rectangle.Width)
                                {
                                    continue;
                                }
                                else
                                {
                                    if (segment.Y1 < Rectangle.Y && segment.Y2 < Rectangle.Y)
                                        continue;
                                    else if ((segment.Y1 > Rectangle.Y + Rectangle.Height) && (segment.Y2 > Rectangle.Y + Rectangle.Height))
                                        continue;
                                    else
                                    {
                                        segment.IsContainsRectangle = true;
                                        PolyLines[p].Segments[s] = segment;
                                    }
                                }
                            }
                            else if (segment.X1 == Rectangle.X || segment.X1 == Rectangle.X + Rectangle.Width)
                            {
                                if (segment.Y1 >= Rectangle.Y || segment.Y1 <= Rectangle.Y + Rectangle.Height)
                                {
                                    segment.IsContainsRectangle = true;
                                    PolyLines[p].Segments[s] = segment;
                                }
                            }
                            else if (segment.X2 == Rectangle.X || segment.X2 == Rectangle.X + Rectangle.Width)
                            {
                                if (segment.Y2 >= Rectangle.Y || segment.Y2 <= Rectangle.Y + Rectangle.Height)
                                {
                                    segment.IsContainsRectangle = true;
                                    PolyLines[p].Segments[s] = segment;
                                }
                            }
                            else
                            {
                                segment.IsContainsRectangle = true;
                                PolyLines[p].Segments[s] = segment;
                            }
                        }
                    }

                    if (PolyLines.Any(p1 => p1.Segments.Any(s1 => s1.IsContainsRectangle)))
                        text = "Отрезки найдены";
                    else
                        text = "Отрезки НЕ найдены";
                }

                catch (Exception exc)
                {
                    text = exc.Message;
                }

                VisibilityProgressBar = Visibility.Hidden;
                StatusText = text;
            });
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}